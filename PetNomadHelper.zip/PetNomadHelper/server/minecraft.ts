import { spawn, ChildProcess } from 'child_process';
import { storage } from './storage';
import { Server } from '@shared/schema';
import * as fs from 'fs/promises';
import * as path from 'path';
import { broadcastConsoleMessage } from './websocket';

export class MinecraftManager {
  private serverProcesses: Map<number, ChildProcess>;
  private consoleHistory: Map<number, { timestamp: string, content: string, type: string }[]>;
  
  constructor() {
    this.serverProcesses = new Map();
    this.consoleHistory = new Map();
    
    // Initialize console history for all servers
    this.initializeConsoleHistory();
  }
  
  private async initializeConsoleHistory() {
    const servers = await storage.getAllServers();
    servers.forEach(server => {
      this.consoleHistory.set(server.id, []);
    });
  }
  
  // Add console message to history and broadcast
  private addConsoleMessage(serverId: number, content: string, type: string = 'info') {
    const timestamp = new Date().toISOString();
    const message = { timestamp, content, type };
    
    // Get or initialize console history for this server
    if (!this.consoleHistory.has(serverId)) {
      this.consoleHistory.set(serverId, []);
    }
    
    const history = this.consoleHistory.get(serverId)!;
    
    // Add to history (max 1000 lines)
    history.push(message);
    if (history.length > 1000) {
      history.shift();
    }
    
    // Broadcast to clients
    broadcastConsoleMessage(serverId, message);
  }
  
  // Get console history for a server
  getConsoleHistory(serverId: number) {
    return this.consoleHistory.get(serverId) || [];
  }
  
  // Parse console output to determine type
  private parseConsoleOutput(line: string): { content: string, type: string } {
    let type = 'info';
    
    if (line.includes('[Server]')) {
      // Server startup/shutdown messages
      type = 'success';
    } else if (line.includes('[Error]') || line.includes('ERROR]')) {
      type = 'error';
    } else if (line.includes('[Warn]') || line.includes('WARN]')) {
      type = 'warning';
    } else if (line.includes('joined the game')) {
      type = 'player';
    } else if (line.includes('[Chat]') || line.match(/<[^>]+>/)) {
      type = 'chat';
    }
    
    return { content: line, type };
  }
  
  // Start a Minecraft server
  async startServer(server: Server): Promise<{ success: boolean, error?: string }> {
    // Check if server is already running
    if (this.serverProcesses.has(server.id)) {
      return { success: false, error: "Server is already running" };
    }
    
    try {
      // Check if server path exists
      try {
        await fs.access(server.path);
      } catch (error) {
        return { success: false, error: `Server path does not exist: ${server.path}` };
      }
      
      // Determine the start command based on server type
      let command: string;
      let args: string[] = [];
      
      if (server.type === 'java') {
        // Java Edition start command
        command = 'java';
        args = [
          '-Xmx2G', // Max memory
          '-Xms1G', // Initial memory
          '-jar',
          'server.jar',
          'nogui'
        ];
      } else if (server.type === 'bedrock') {
        // Bedrock Edition start command
        if (process.platform === 'win32') {
          command = 'bedrock_server.exe';
        } else {
          command = './bedrock_server';
        }
      } else {
        return { success: false, error: `Unsupported server type: ${server.type}` };
      }
      
      // Log server start attempt
      this.addConsoleMessage(server.id, `[Server] Starting ${server.name} (${server.type} ${server.version})...`, 'info');
      
      // Spawn the server process
      const process = spawn(command, args, {
        cwd: server.path,
        stdio: ['pipe', 'pipe', 'pipe']
      });
      
      // Store the process
      this.serverProcesses.set(server.id, process);
      
      // Log stdout
      process.stdout.on('data', (data) => {
        const lines = data.toString().split('\n').filter((line: string) => line.trim() !== '');
        lines.forEach((line: string) => {
          const parsed = this.parseConsoleOutput(line);
          this.addConsoleMessage(server.id, parsed.content, parsed.type);
        });
      });
      
      // Log stderr
      process.stderr.on('data', (data) => {
        const lines = data.toString().split('\n').filter((line: string) => line.trim() !== '');
        lines.forEach((line: string) => {
          this.addConsoleMessage(server.id, line, 'error');
        });
      });
      
      // Handle process exit
      process.on('exit', (code, signal) => {
        this.addConsoleMessage(server.id, `[Server] Server stopped with code ${code}`, code === 0 ? 'success' : 'error');
        this.serverProcesses.delete(server.id);
        storage.updateServerStatus(server.id, 'offline');
      });
      
      // Update server status in storage
      await storage.updateServerStatus(server.id, 'online');
      
      // Start performance monitoring for this server
      this.monitorServerPerformance(server.id);
      
      return { success: true };
    } catch (error) {
      this.addConsoleMessage(server.id, `[Error] Failed to start server: ${error}`, 'error');
      return { success: false, error: `Failed to start server: ${error}` };
    }
  }
  
  // Stop a Minecraft server
  async stopServer(server: Server): Promise<{ success: boolean, error?: string }> {
    // Check if server is running
    const process = this.serverProcesses.get(server.id);
    if (!process) {
      return { success: false, error: "Server is not running" };
    }
    
    try {
      // Send stop command to server
      this.sendCommand(server.id, 'stop');
      
      // Give the server some time to shut down gracefully
      await new Promise<void>((resolve) => {
        // Wait up to 30 seconds for the server to stop
        const timeout = setTimeout(() => {
          // If it doesn't stop, force kill
          if (this.serverProcesses.has(server.id)) {
            process.kill('SIGKILL');
            this.addConsoleMessage(server.id, '[Server] Server forcefully terminated', 'warning');
          }
          resolve();
        }, 30000);
        
        // If server stops properly, clear the timeout
        process.on('exit', () => {
          clearTimeout(timeout);
          resolve();
        });
      });
      
      return { success: true };
    } catch (error) {
      return { success: false, error: `Failed to stop server: ${error}` };
    }
  }
  
  // Restart a Minecraft server
  async restartServer(server: Server): Promise<{ success: boolean, error?: string }> {
    // Stop the server if it's running
    if (this.serverProcesses.has(server.id)) {
      const stopResult = await this.stopServer(server);
      if (!stopResult.success) {
        return stopResult;
      }
      
      // Wait for the server to fully stop
      await new Promise((resolve) => setTimeout(resolve, 5000));
    }
    
    // Start the server
    return this.startServer(server);
  }
  
  // Send a command to a running server
  sendCommand(serverId: number, command: string): boolean {
    const process = this.serverProcesses.get(serverId);
    if (!process || !process.stdin) {
      return false;
    }
    
    try {
      // Log the command
      this.addConsoleMessage(serverId, `> ${command}`, 'info');
      
      // Send the command to the server
      process.stdin.write(command + '\n');
      return true;
    } catch (error) {
      this.addConsoleMessage(serverId, `[Error] Failed to send command: ${error}`, 'error');
      return false;
    }
  }
  
  // Monitor server performance (CPU, memory)
  private async monitorServerPerformance(serverId: number) {
    // Only monitor if server is running
    if (!this.serverProcesses.has(serverId)) {
      return;
    }
    
    const process = this.serverProcesses.get(serverId)!;
    
    try {
      // Get server from storage
      const server = await storage.getServer(serverId);
      if (!server) {
        return;
      }
      
      // Get process info
      const pid = process.pid;
      
      // This is a simplified version - in a real implementation,
      // you would use a library like ps-node or node-ps to get actual process stats
      const cpuUsage = Math.floor(Math.random() * 40) + 10; // Random value between 10-50%
      const memoryMB = Math.floor(Math.random() * 2000) + 1000; // Random value between 1000-3000 MB
      const memoryGB = (memoryMB / 1024).toFixed(1);
      const memoryPercent = Math.floor((memoryMB / 4096) * 100); // Assuming 4GB max
      
      // Update server performance in storage
      await storage.updateServerPerformance(serverId, {
        cpu: `${cpuUsage}%`,
        memory: `${memoryGB} GB`,
        memoryPercent
      });
      
      // Calculate uptime
      const uptime = this.calculateUptime(process.pid);
      await storage.updateServerUptime(serverId, uptime);
      
      // Schedule next update in 5 seconds if server is still running
      setTimeout(() => {
        if (this.serverProcesses.has(serverId)) {
          this.monitorServerPerformance(serverId);
        }
      }, 5000);
    } catch (error) {
      console.error(`Error monitoring server ${serverId}:`, error);
    }
  }
  
  // Calculate server uptime in human-readable format
  private calculateUptime(pid: number): string {
    // In a real implementation, you would get the actual process start time
    // For this demo, we'll use a random value
    const uptimeSeconds = Math.floor(Math.random() * 100000) + 3600; // Random uptime > 1 hour
    
    const days = Math.floor(uptimeSeconds / 86400);
    const hours = Math.floor((uptimeSeconds % 86400) / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    
    let uptime = '';
    if (days > 0) uptime += `${days}d `;
    if (hours > 0 || days > 0) uptime += `${hours}h `;
    uptime += `${minutes}m`;
    
    return uptime;
  }
}
