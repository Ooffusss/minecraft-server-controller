import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupWebSocketServer } from "./websocket";
import { MinecraftManager } from "./minecraft";
import { SystemMonitor } from "./system";
import { setupAuth } from "./auth";
import { z } from "zod";
import { WebSocketServer } from "ws";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Initialize WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  setupWebSocketServer(wss);
  
  // Setup authentication
  setupAuth(app);
  
  // Initialize Minecraft Manager and System Monitor
  const minecraftManager = new MinecraftManager();
  const systemMonitor = new SystemMonitor();
  
  // API Routes
  
  // Get system stats
  app.get("/api/system/stats", async (req: Request, res: Response) => {
    try {
      const stats = await systemMonitor.getStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to get system stats" });
    }
  });
  
  // Get all servers
  app.get("/api/servers", async (req: Request, res: Response) => {
    try {
      const servers = await storage.getAllServers();
      res.json(servers);
    } catch (error) {
      res.status(500).json({ error: "Failed to get servers" });
    }
  });
  
  // Get server by ID
  app.get("/api/servers/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const server = await storage.getServer(id);
      
      if (!server) {
        return res.status(404).json({ error: "Server not found" });
      }
      
      // Get online players for this server
      const players = await storage.getPlayersByServer(id);
      
      res.json({
        ...server,
        players
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to get server" });
    }
  });
  
  // Create server
  app.post("/api/servers", async (req: Request, res: Response) => {
    try {
      const serverData = req.body;
      const server = await storage.createServer(serverData);
      res.status(201).json(server);
    } catch (error) {
      res.status(500).json({ error: "Failed to create server" });
    }
  });
  
  // Start server
  app.post("/api/servers/:id/start", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const server = await storage.getServer(id);
      
      if (!server) {
        return res.status(404).json({ error: "Server not found" });
      }
      
      const result = await minecraftManager.startServer(server);
      if (result.success) {
        await storage.updateServerStatus(id, "online");
        res.json({ message: "Server started" });
      } else {
        res.status(500).json({ error: result.error });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to start server" });
    }
  });
  
  // Stop server
  app.post("/api/servers/:id/stop", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const server = await storage.getServer(id);
      
      if (!server) {
        return res.status(404).json({ error: "Server not found" });
      }
      
      const result = await minecraftManager.stopServer(server);
      if (result.success) {
        await storage.updateServerStatus(id, "offline");
        res.json({ message: "Server stopped" });
      } else {
        res.status(500).json({ error: result.error });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to stop server" });
    }
  });
  
  // Restart server
  app.post("/api/servers/:id/restart", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const server = await storage.getServer(id);
      
      if (!server) {
        return res.status(404).json({ error: "Server not found" });
      }
      
      const result = await minecraftManager.restartServer(server);
      if (result.success) {
        res.json({ message: "Server restarting" });
      } else {
        res.status(500).json({ error: result.error });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to restart server" });
    }
  });
  
  // Get server players
  app.get("/api/servers/:id/players", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const players = await storage.getPlayersByServer(id);
      res.json(players);
    } catch (error) {
      res.status(500).json({ error: "Failed to get players" });
    }
  });
  
  // Get all tasks
  app.get("/api/tasks", async (req: Request, res: Response) => {
    try {
      const tasks = await storage.getAllTasks();
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ error: "Failed to get tasks" });
    }
  });
  
  // Create task
  app.post("/api/tasks", async (req: Request, res: Response) => {
    try {
      const taskData = req.body;
      const task = await storage.createTask(taskData);
      res.status(201).json(task);
    } catch (error) {
      res.status(500).json({ error: "Failed to create task" });
    }
  });
  
  // Delete task
  app.delete("/api/tasks/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteTask(id);
      res.json({ message: "Task deleted" });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete task" });
    }
  });
  
  // User routes
  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const userData = req.body;
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to create user" });
    }
  });
  
  app.get("/api/users", async (req: Request, res: Response) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ error: "Failed to get users" });
    }
  });
  
  return httpServer;
}
