import { 
  User, InsertUser, 
  Server, InsertServer, 
  Player, InsertPlayer, 
  Backup, InsertBackup, 
  Task, InsertTask,
  users, servers, players, backups, tasks
} from "@shared/schema";
import { db, pool } from "./db";
import { eq, and } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  
  // Server methods
  getServer(id: number): Promise<Server | undefined>;
  getAllServers(): Promise<Server[]>;
  createServer(server: InsertServer): Promise<Server>;
  updateServerStatus(id: number, status: string): Promise<Server>;
  updateServerPerformance(id: number, performance: any): Promise<Server>;
  updateServerUptime(id: number, uptime: string): Promise<Server>;
  
  // Player methods
  getPlayer(id: number): Promise<Player | undefined>;
  getPlayerByUsername(username: string): Promise<Player | undefined>;
  createPlayer(player: InsertPlayer): Promise<Player>;
  getPlayersByServer(serverId: number): Promise<Player[]>;
  updatePlayerLocation(id: number, location: string): Promise<Player>;
  updatePlayerGameMode(id: number, gameMode: string): Promise<Player>;
  
  // Backup methods
  getBackup(id: number): Promise<Backup | undefined>;
  getBackupsByServer(serverId: number): Promise<Backup[]>;
  createBackup(backup: InsertBackup): Promise<Backup>;
  
  // Task methods
  getTask(id: number): Promise<Task | undefined>;
  getAllTasks(): Promise<Task[]>;
  getTasksByServer(serverId: number): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTaskStatus(id: number, status: string): Promise<Task>;
  deleteTask(id: number): Promise<void>;
  
  // Session store
  sessionStore: session.Store;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    // Initialize session store
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }
  
  // Server methods
  async getServer(id: number): Promise<Server | undefined> {
    const [server] = await db.select().from(servers).where(eq(servers.id, id));
    return server;
  }
  
  async getAllServers(): Promise<Server[]> {
    return await db.select().from(servers);
  }
  
  async createServer(insertServer: InsertServer): Promise<Server> {
    const [server] = await db
      .insert(servers)
      .values(insertServer)
      .returning();
    return server;
  }
  
  async updateServerStatus(id: number, status: string): Promise<Server> {
    const [server] = await db
      .update(servers)
      .set({ status })
      .where(eq(servers.id, id))
      .returning();
    
    if (!server) {
      throw new Error(`Server with ID ${id} not found`);
    }
    
    return server;
  }
  
  async updateServerPerformance(id: number, performance: any): Promise<Server> {
    const [server] = await db
      .update(servers)
      .set({ performance })
      .where(eq(servers.id, id))
      .returning();
    
    if (!server) {
      throw new Error(`Server with ID ${id} not found`);
    }
    
    return server;
  }
  
  async updateServerUptime(id: number, uptime: string): Promise<Server> {
    const [server] = await db
      .update(servers)
      .set({ uptime })
      .where(eq(servers.id, id))
      .returning();
    
    if (!server) {
      throw new Error(`Server with ID ${id} not found`);
    }
    
    return server;
  }
  
  // Player methods
  async getPlayer(id: number): Promise<Player | undefined> {
    const [player] = await db.select().from(players).where(eq(players.id, id));
    return player;
  }
  
  async getPlayerByUsername(username: string): Promise<Player | undefined> {
    const [player] = await db.select().from(players).where(eq(players.username, username));
    return player;
  }
  
  async createPlayer(insertPlayer: InsertPlayer): Promise<Player> {
    const [player] = await db
      .insert(players)
      .values(insertPlayer)
      .returning();
    return player;
  }
  
  async getPlayersByServer(serverId: number): Promise<Player[]> {
    return await db
      .select()
      .from(players)
      .where(eq(players.currentServer, serverId));
  }
  
  async updatePlayerLocation(id: number, location: string): Promise<Player> {
    const [player] = await db
      .update(players)
      .set({ location })
      .where(eq(players.id, id))
      .returning();
    
    if (!player) {
      throw new Error(`Player with ID ${id} not found`);
    }
    
    return player;
  }
  
  async updatePlayerGameMode(id: number, gameMode: string): Promise<Player> {
    const [player] = await db
      .update(players)
      .set({ gameMode })
      .where(eq(players.id, id))
      .returning();
    
    if (!player) {
      throw new Error(`Player with ID ${id} not found`);
    }
    
    return player;
  }
  
  // Backup methods
  async getBackup(id: number): Promise<Backup | undefined> {
    const [backup] = await db.select().from(backups).where(eq(backups.id, id));
    return backup;
  }
  
  async getBackupsByServer(serverId: number): Promise<Backup[]> {
    return await db
      .select()
      .from(backups)
      .where(eq(backups.serverId, serverId));
  }
  
  async createBackup(insertBackup: InsertBackup): Promise<Backup> {
    const [backup] = await db
      .insert(backups)
      .values(insertBackup)
      .returning();
    return backup;
  }
  
  // Task methods
  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task;
  }
  
  async getAllTasks(): Promise<Task[]> {
    return await db.select().from(tasks);
  }
  
  async getTasksByServer(serverId: number): Promise<Task[]> {
    return await db
      .select()
      .from(tasks)
      .where(eq(tasks.serverId, serverId));
  }
  
  async createTask(insertTask: InsertTask): Promise<Task> {
    const [task] = await db
      .insert(tasks)
      .values(insertTask)
      .returning();
    return task;
  }
  
  async updateTaskStatus(id: number, status: string): Promise<Task> {
    const now = new Date();
    const [task] = await db
      .update(tasks)
      .set({ lastStatus: status, lastRun: now })
      .where(eq(tasks.id, id))
      .returning();
    
    if (!task) {
      throw new Error(`Task with ID ${id} not found`);
    }
    
    return task;
  }
  
  async deleteTask(id: number): Promise<void> {
    const result = await db
      .delete(tasks)
      .where(eq(tasks.id, id));
      
    // No easy way to check if anything was deleted with Drizzle ORM
    // We're just assuming it worked
  }

  async initSampleData() {
    try {
      // Check if we already have users
      const existingUsers = await this.getAllUsers();
      if (existingUsers.length > 0) {
        console.log('Sample data already exists, skipping initialization');
        return;
      }

      // Sample admin user
      const admin = await this.createUser({
        username: 'admin',
        password: 'admin123',
        email: 'admin@example.com',
        role: 'admin'
      });
      
      // Sample servers
      const survivalServer = await this.createServer({
        name: 'Survival Server',
        type: 'java',
        version: '1.19.2',
        port: 25565,
        path: '/opt/minecraft/survival',
        maxPlayers: 20,
        autoStart: true,
        autoRestart: true
      });
      
      // Update server status and performance
      await this.updateServerStatus(survivalServer.id, 'online');
      await this.updateServerPerformance(survivalServer.id, {
        cpu: '28%',
        memory: '2.4 GB',
        memoryPercent: 60
      });
      await this.updateServerUptime(survivalServer.id, '3d 7h 22m');
      
      // Add some players
      const player1 = await this.createPlayer({
        username: 'Player123',
        uuid: 'abc123'
      });
      
      await db
        .update(players)
        .set({
          currentServer: survivalServer.id,
          gameMode: 'Survival Mode',
          location: '245, 68, -192',
          lastLogin: new Date(),
          totalPlaytime: 13320 // 3h 42m in seconds
        })
        .where(eq(players.id, player1.id));
      
      const player2 = await this.createPlayer({
        username: 'Miner5523',
        uuid: 'def456'
      });
      
      await db
        .update(players)
        .set({
          currentServer: survivalServer.id,
          gameMode: 'Survival Mode',
          location: '76, 42, 89',
          lastLogin: new Date(),
          totalPlaytime: 4500 // 1h 15m in seconds
        })
        .where(eq(players.id, player2.id));
      
      const creativeServer = await this.createServer({
        name: 'Creative Server',
        type: 'java',
        version: '1.19.2',
        port: 25566,
        path: '/opt/minecraft/creative',
        maxPlayers: 10,
        autoStart: true,
        autoRestart: true
      });
      
      await this.updateServerStatus(creativeServer.id, 'online');
      await this.updateServerPerformance(creativeServer.id, {
        cpu: '14%',
        memory: '1.2 GB',
        memoryPercent: 30
      });
      await this.updateServerUptime(creativeServer.id, '1d 3h 45m');
      
      const player3 = await this.createPlayer({
        username: 'CraftMaster',
        uuid: 'ghi789'
      });
      
      await db
        .update(players)
        .set({
          currentServer: creativeServer.id,
          gameMode: 'Creative Mode',
          location: '120, 104, -35',
          lastLogin: new Date(),
          totalPlaytime: 2700 // 45m in seconds
        })
        .where(eq(players.id, player3.id));
      
      await this.createServer({
        name: 'Bedrock Server',
        type: 'bedrock',
        version: '1.19.70',
        port: 19132,
        path: '/opt/minecraft/bedrock',
        maxPlayers: 30,
        autoStart: false,
        autoRestart: false
      });
      
      // Sample tasks
      const task1 = await this.createTask({
        name: 'Daily Backup',
        serverId: survivalServer.id,
        action: 'backup',
        schedule: 'Daily at 03:00 AM',
        active: true,
        parameters: { destination: '/backups/daily' }
      });
      
      await db
        .update(tasks)
        .set({
          lastRun: new Date('2023-08-12T03:00:00Z'),
          lastStatus: 'success'
        })
        .where(eq(tasks.id, task1.id));
      
      const task2 = await this.createTask({
        name: 'Restart Server',
        serverId: creativeServer.id,
        action: 'restart',
        schedule: 'Every 12 hours',
        active: true,
        parameters: {}
      });
      
      await db
        .update(tasks)
        .set({
          lastRun: new Date('2023-08-12T12:00:00Z'),
          lastStatus: 'success'
        })
        .where(eq(tasks.id, task2.id));
      
      const task3 = await this.createTask({
        name: 'Weekly Backup',
        serverId: null,
        action: 'backup',
        schedule: 'Sunday at 04:00 AM',
        active: true,
        parameters: { destination: '/backups/weekly', all: true }
      });
      
      await db
        .update(tasks)
        .set({
          lastRun: new Date('2023-08-06T04:00:00Z'),
          lastStatus: 'partial'
        })
        .where(eq(tasks.id, task3.id));
        
      console.log('Sample data initialized successfully');
    } catch (error) {
      console.error('Error initializing sample data:', error);
    }
  }
}

export const storage = new DatabaseStorage();

// Initialize sample data
storage.initSampleData()
  .then(() => console.log('Storage initialized'))
  .catch(err => console.error('Failed to initialize storage:', err));