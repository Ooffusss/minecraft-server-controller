// This is a simplified system monitor for demo purposes
// In a real implementation, you would use a library like systeminformation

export class SystemMonitor {
  constructor() {}
  
  // Get system stats (CPU, memory, disk usage)
  async getStats() {
    // In a real implementation, these would be actual system values
    // For demo purposes, we'll return some realistic mock data
    
    // CPU usage (random between 30-60%)
    const cpuPercent = Math.floor(Math.random() * 30) + 30;
    
    // Memory usage (random between 2-6 GB of 8GB total)
    const memoryUsedGB = (Math.floor(Math.random() * 40) + 20) / 10; // 2.0 to 6.0 GB
    const memoryTotalGB = 8;
    const memoryPercent = Math.floor((memoryUsedGB / memoryTotalGB) * 100);
    
    // Disk usage (random between 100-200 GB of 500GB total)
    const diskUsedGB = Math.floor(Math.random() * 100) + 100;
    const diskTotalGB = 500;
    const diskPercent = Math.floor((diskUsedGB / diskTotalGB) * 100);
    
    // Players trend (random between -3 and +5)
    const playersTrend = Math.floor(Math.random() * 9) - 3;
    const trendPrefix = playersTrend > 0 ? '+' : '';
    
    // Get all servers from storage to calculate total players
    const servers = await this.getServersForStatsDemo();
    
    // Calculate active players
    const activePlayers = servers.reduce((sum, server) => {
      return sum + (server.players || 0);
    }, 0);
    
    // Calculate max players
    const maxPlayers = servers.reduce((sum, server) => {
      return sum + (server.maxPlayers || 0);
    }, 0);
    
    return {
      cpu: cpuPercent,
      memory: {
        used: memoryUsedGB,
        total: memoryTotalGB,
        percent: memoryPercent,
        formatted: `${memoryUsedGB.toFixed(1)} GB / ${memoryTotalGB} GB`
      },
      disk: {
        used: diskUsedGB,
        total: diskTotalGB,
        percent: diskPercent,
        formatted: `${diskUsedGB} GB / ${diskTotalGB} GB`
      },
      players: {
        active: `${activePlayers} / ${maxPlayers}`,
        trend: `${trendPrefix}${playersTrend}`
      }
    };
  }
  
  // Demo helper method to get servers for stats calculation
  private async getServersForStatsDemo() {
    return [
      { name: 'Survival Server', status: 'online', players: 8, maxPlayers: 20 },
      { name: 'Creative Server', status: 'online', players: 2, maxPlayers: 10 },
      { name: 'Bedrock Server', status: 'offline', players: 0, maxPlayers: 30 }
    ];
  }
}
