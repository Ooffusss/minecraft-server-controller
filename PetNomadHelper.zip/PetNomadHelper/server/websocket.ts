import { WebSocketServer, WebSocket } from 'ws';
import { storage } from './storage';
import { MinecraftManager } from './minecraft';

// Initialize MinecraftManager
const minecraftManager = new MinecraftManager();

// Store connected clients
const clients: WebSocket[] = [];

// WebSocket message handler
function handleMessage(ws: WebSocket, message: string) {
  try {
    const data = JSON.parse(message);
    
    // Handle different message types
    switch (data.type) {
      case 'command':
        // Send command to Minecraft server
        if (data.serverId && data.command) {
          const success = minecraftManager.sendCommand(
            parseInt(data.serverId), 
            data.command
          );
          
          if (!success) {
            sendError(ws, 'Failed to send command to server');
          }
        }
        break;
        
      case 'getConsoleHistory':
        // Send console history for a specific server
        if (data.serverId) {
          const history = minecraftManager.getConsoleHistory(parseInt(data.serverId));
          
          ws.send(JSON.stringify({
            type: 'consoleHistory',
            serverId: data.serverId,
            history
          }));
        }
        break;
        
      default:
        sendError(ws, 'Unknown message type');
    }
  } catch (error) {
    sendError(ws, `Error processing message: ${error}`);
  }
}

// Send error message to client
function sendError(ws: WebSocket, message: string) {
  ws.send(JSON.stringify({
    type: 'error',
    message
  }));
}

// Broadcast console message to all connected clients
export function broadcastConsoleMessage(serverId: number, message: any) {
  const messageData = JSON.stringify({
    type: 'console',
    serverId,
    message
  });
  
  clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(messageData);
    }
  });
}

// Set up WebSocket server
export function setupWebSocketServer(wss: WebSocketServer) {
  wss.on('connection', (ws) => {
    // Add new client to list
    clients.push(ws);
    
    // Handle incoming messages
    ws.on('message', (message) => {
      handleMessage(ws, message.toString());
    });
    
    // Handle disconnection
    ws.on('close', () => {
      // Remove client from list
      const index = clients.indexOf(ws);
      if (index !== -1) {
        clients.splice(index, 1);
      }
    });
    
    // Send initial connection success message
    ws.send(JSON.stringify({
      type: 'connected',
      message: 'Connected to Minecraft Server Controller'
    }));
  });
  
  console.log('WebSocket server initialized');
}
