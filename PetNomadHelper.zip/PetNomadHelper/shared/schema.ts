import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull(),
  role: text("role").default("user").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  role: true,
});

// Server model
export const servers = pgTable("servers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // java, bedrock
  version: text("version").notNull(),
  port: integer("port").notNull(),
  status: text("status").default("offline").notNull(), // online, offline
  path: text("path").notNull(),
  maxPlayers: integer("max_players").default(20).notNull(),
  autoStart: boolean("auto_start").default(false).notNull(),
  autoRestart: boolean("auto_restart").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  performance: json("performance").$type<{
    cpu: string;
    memory: string;
    memoryPercent: number;
  }>(),
  uptime: text("uptime"),
});

export const insertServerSchema = createInsertSchema(servers).pick({
  name: true,
  type: true,
  version: true,
  port: true,
  path: true,
  maxPlayers: true,
  autoStart: true,
  autoRestart: true,
});

// Player model
export const players = pgTable("players", {
  id: serial("id").primaryKey(),
  username: text("username").notNull(),
  uuid: text("uuid"),
  lastLogin: timestamp("last_login"),
  totalPlaytime: integer("total_playtime").default(0),
  currentServer: integer("current_server").references(() => servers.id),
  location: text("location"),
  gameMode: text("game_mode"),
});

export const insertPlayerSchema = createInsertSchema(players).pick({
  username: true,
  uuid: true,
});

// Backup model
export const backups = pgTable("backups", {
  id: serial("id").primaryKey(),
  serverId: integer("server_id").references(() => servers.id).notNull(),
  path: text("path").notNull(),
  size: integer("size"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  type: text("type").default("manual").notNull(), // manual, scheduled
});

export const insertBackupSchema = createInsertSchema(backups).pick({
  serverId: true,
  path: true,
  size: true,
  type: true,
});

// Task model
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  serverId: integer("server_id").references(() => servers.id),
  action: text("action").notNull(), // backup, restart, command
  schedule: text("schedule").notNull(),
  active: boolean("active").default(true).notNull(),
  lastRun: timestamp("last_run"),
  lastStatus: text("last_status"), // success, failed, partial
  parameters: json("parameters"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  name: true,
  serverId: true,
  action: true,
  schedule: true,
  active: true,
  parameters: true,
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  servers: many(servers),
}));

export const serversRelations = relations(servers, ({ many }) => ({
  players: many(players),
  backups: many(backups),
  tasks: many(tasks),
}));

export const playersRelations = relations(players, ({ one }) => ({
  server: one(servers, {
    fields: [players.currentServer],
    references: [servers.id],
  }),
}));

export const backupsRelations = relations(backups, ({ one }) => ({
  server: one(servers, {
    fields: [backups.serverId],
    references: [servers.id],
  }),
}));

export const tasksRelations = relations(tasks, ({ one }) => ({
  server: one(servers, {
    fields: [tasks.serverId],
    references: [servers.id],
  }),
}));

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Server = typeof servers.$inferSelect;
export type InsertServer = z.infer<typeof insertServerSchema>;

export type Player = typeof players.$inferSelect;
export type InsertPlayer = z.infer<typeof insertPlayerSchema>;

export type Backup = typeof backups.$inferSelect;
export type InsertBackup = z.infer<typeof insertBackupSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
