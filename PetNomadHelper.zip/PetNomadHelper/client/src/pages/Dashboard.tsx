import { useState, useEffect } from 'react';
import Sidebar from '@/components/layout/Sidebar';
import Navbar from '@/components/layout/Navbar';
import MetricCard from '@/components/dashboard/MetricCard';
import ServerCard from '@/components/dashboard/ServerCard';
import { Console } from '@/components/console/Console';
import PlayerList from '@/components/dashboard/PlayerList';
import TaskTable from '@/components/dashboard/TaskTable';
import { useQuery } from '@tanstack/react-query';

type DashboardProps = {
  socket: WebSocket | null;
};

export default function Dashboard({ socket }: DashboardProps) {
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  const [activeConsoleServer, setActiveConsoleServer] = useState<string | null>(null);
  const [consoleCommand, setConsoleCommand] = useState('');

  // Get system stats
  const { data: systemStats } = useQuery<any>({
    queryKey: ['/api/system/stats'],
    refetchInterval: 5000 // Refresh every 5 seconds
  });

  // Get all servers
  const { data: servers } = useQuery<any[]>({
    queryKey: ['/api/servers']
  });

  // Get scheduled tasks
  const { data: tasks } = useQuery<any[]>({
    queryKey: ['/api/tasks']
  });

  // Get online players for the active console server
  const { data: players } = useQuery<any[]>({
    queryKey: ['/api/servers', activeConsoleServer, 'players'],
    enabled: !!activeConsoleServer
  });

  // Send console command
  const handleSendCommand = () => {
    if (!activeConsoleServer || !consoleCommand.trim()) return;
    
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: 'command',
        serverId: activeConsoleServer,
        command: consoleCommand
      }));
      setConsoleCommand('');
    }
  };

  useEffect(() => {
    // Set the first online server as the active console server when servers data is loaded
    if (servers && servers.length > 0) {
      const onlineServer = servers.find((server: any) => server.status === 'online');
      if (onlineServer) {
        setActiveConsoleServer(onlineServer.id);
      } else {
        setActiveConsoleServer(servers[0].id);
      }
    }
  }, [servers]);

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile sidebar */}
      {showMobileSidebar && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setShowMobileSidebar(false)} />
          <div className="fixed inset-y-0 left-0 z-40 w-64">
            <Sidebar />
          </div>
        </div>
      )}
      
      {/* Desktop sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex flex-col flex-1 w-0 overflow-hidden">
        <Navbar onToggleSidebar={() => setShowMobileSidebar(!showMobileSidebar)} />
        
        {/* Page Content */}
        <main className="flex-1 overflow-y-auto bg-background focus:outline-none">
          <div className="py-6">
            <div className="px-4 mx-auto sm:px-6 md:px-8">
              <h1 className="text-2xl font-semibold text-textPrimary">Dashboard</h1>
            </div>
            
            <div className="px-4 mx-auto mt-6 sm:px-6 md:px-8">
              {/* System Overview */}
              <div className="grid grid-cols-1 gap-5 mt-2 sm:grid-cols-2 lg:grid-cols-4">
                <MetricCard
                  title="CPU Usage"
                  value={systemStats?.cpu ? `${systemStats.cpu}%` : 'Loading...'}
                  icon="fas fa-microchip"
                  iconColor="accent"
                  progress={systemStats?.cpu || 0}
                  progressColor="accent"
                />
                
                <MetricCard
                  title="Memory Usage"
                  value={systemStats?.memory?.formatted || 'Loading...'}
                  icon="fas fa-memory"
                  iconColor="warning"
                  progress={systemStats?.memory?.percent || 0}
                  progressColor="warning"
                />
                
                <MetricCard
                  title="Disk Usage"
                  value={systemStats?.disk?.formatted || 'Loading...'}
                  icon="fas fa-hdd"
                  iconColor="success"
                  progress={systemStats?.disk?.percent || 0}
                  progressColor="success"
                />
                
                <MetricCard
                  title="Active Players"
                  value={systemStats?.players?.active || '0 / 0'}
                  icon="fas fa-users"
                  iconColor="accent"
                  subtext={`${systemStats?.players?.trend || "+0"} players in the last hour`}
                />
              </div>
              
              {/* Servers */}
              <div className="mt-8">
                <h2 className="flex items-center text-lg font-medium text-textPrimary">
                  My Servers
                  <button className="ml-3 p-1 text-sm text-accent hover:bg-accent hover:bg-opacity-10 rounded-md">
                    <i className="fas fa-plus-circle"></i> Add Server
                  </button>
                </h2>
                
                <div className="mt-4 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
                  {servers && servers.map((server: any) => (
                    <ServerCard
                      key={server.id}
                      server={server}
                      onConsoleClick={() => setActiveConsoleServer(server.id)}
                    />
                  ))}
                  
                  {!servers && (
                    <div className="col-span-3 text-center py-10 text-textSecondary">
                      Loading servers...
                    </div>
                  )}
                  
                  {servers && servers.length === 0 && (
                    <div className="col-span-3 text-center py-10 text-textSecondary">
                      No servers found. Add a server to get started.
                    </div>
                  )}
                </div>
              </div>
              
              {/* Console & Players Section */}
              <div className="mt-8 grid grid-cols-1 gap-5 lg:grid-cols-3">
                {/* Console Output (2 columns) */}
                <div className="lg:col-span-2 bg-foreground rounded-lg shadow">
                  <div className="px-4 py-5 border-b border-border sm:px-6 flex justify-between items-center">
                    <h3 className="text-lg font-medium text-textPrimary">
                      <span className="mr-2">
                        Console - {servers?.find((s: any) => s.id === activeConsoleServer)?.name || 'Select Server'}
                      </span>
                      {servers?.find((s: any) => s.id === activeConsoleServer)?.status === 'online' && (
                        <span className="px-2 py-1 text-xs rounded-md bg-success bg-opacity-10 text-success">Online</span>
                      )}
                      {servers?.find((s: any) => s.id === activeConsoleServer)?.status === 'offline' && (
                        <span className="px-2 py-1 text-xs rounded-md bg-danger bg-opacity-10 text-danger">Offline</span>
                      )}
                    </h3>
                    <div className="flex">
                      <button className="p-1 text-textSecondary hover:text-accent">
                        <i className="fas fa-expand-alt"></i>
                      </button>
                      <button className="ml-3 p-1 text-textSecondary hover:text-accent">
                        <i className="fas fa-ellipsis-v"></i>
                      </button>
                    </div>
                  </div>
                  <div className="px-4 py-5 sm:p-6">
                    <Console serverId={activeConsoleServer} socket={socket} />
                    <div className="flex mt-4 items-center">
                      <div className="flex-grow">
                        <input 
                          type="text" 
                          placeholder="Type command..." 
                          className="w-full rounded-md border border-border bg-background text-textPrimary px-4 py-2 focus:outline-none focus:ring-1 focus:ring-accent"
                          value={consoleCommand}
                          onChange={(e) => setConsoleCommand(e.target.value)}
                          onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                              handleSendCommand();
                            }
                          }}
                        />
                      </div>
                      <button 
                        className="ml-2 px-4 py-2 rounded-md bg-accent text-white hover:bg-opacity-90"
                        onClick={handleSendCommand}
                      >
                        Send
                      </button>
                    </div>
                  </div>
                </div>

                {/* Players List (1 column) */}
                <PlayerList players={players || []} />
              </div>
              
              {/* Scheduled Tasks */}
              <TaskTable tasks={tasks || []} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
