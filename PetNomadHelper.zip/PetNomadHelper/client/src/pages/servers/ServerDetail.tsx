import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useLocation, Link } from 'wouter';
import Sidebar from '@/components/layout/Sidebar';
import Navbar from '@/components/layout/Navbar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Console } from '@/components/console/Console';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

type ServerDetailProps = {
  id: string;
  socket: WebSocket | null;
};

export default function ServerDetail({ id, socket }: ServerDetailProps) {
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  const [location, navigate] = useLocation();
  const [consoleCommand, setConsoleCommand] = useState('');
  const { toast } = useToast();
  
  // Get server details
  const { data: server, isLoading } = useQuery<any>({
    queryKey: ['/api/servers', id],
  });
  
  // Update server status mutation
  const updateServerStatus = useMutation({
    mutationFn: async (status: 'start' | 'stop' | 'restart') => {
      return apiRequest('POST', `/api/servers/${id}/${status}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/servers', id] });
      queryClient.invalidateQueries({ queryKey: ['/api/servers'] });
      toast({
        title: "Server Updated",
        description: "Server status changed successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update server: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Handle server start/stop/restart
  const handleServerAction = (action: 'start' | 'stop' | 'restart') => {
    updateServerStatus.mutate(action);
  };

  // Send console command
  const handleSendCommand = () => {
    if (!consoleCommand.trim()) return;
    
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: 'command',
        serverId: id,
        command: consoleCommand
      }));
      setConsoleCommand('');
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex h-screen overflow-hidden">
        <Sidebar />
        <div className="flex flex-col flex-1 w-0 overflow-hidden">
          <Navbar onToggleSidebar={() => setShowMobileSidebar(!showMobileSidebar)} />
          <main className="flex-1 overflow-y-auto bg-background focus:outline-none">
            <div className="py-6 px-4 mx-auto sm:px-6 md:px-8">
              <div className="flex justify-center items-center h-64">
                <p className="text-textSecondary">Loading server details...</p>
              </div>
            </div>
          </main>
        </div>
      </div>
    );
  }
  
  if (!server) {
    return (
      <div className="flex h-screen overflow-hidden">
        <Sidebar />
        <div className="flex flex-col flex-1 w-0 overflow-hidden">
          <Navbar onToggleSidebar={() => setShowMobileSidebar(!showMobileSidebar)} />
          <main className="flex-1 overflow-y-auto bg-background focus:outline-none">
            <div className="py-6 px-4 mx-auto sm:px-6 md:px-8">
              <div className="flex flex-col justify-center items-center h-64">
                <p className="text-textSecondary">Server not found</p>
                <Link href="/" className="mt-4 text-accent hover:underline">
                  Back to Dashboard
                </Link>
              </div>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile sidebar */}
      {showMobileSidebar && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setShowMobileSidebar(false)} />
          <div className="fixed inset-y-0 left-0 z-40 w-64">
            <Sidebar />
          </div>
        </div>
      )}
      
      {/* Desktop sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex flex-col flex-1 w-0 overflow-hidden">
        <Navbar onToggleSidebar={() => setShowMobileSidebar(!showMobileSidebar)} />
        
        {/* Page Content */}
        <main className="flex-1 overflow-y-auto bg-background focus:outline-none">
          <div className="py-6">
            <div className="px-4 mx-auto sm:px-6 md:px-8">
              <div className="flex items-center mb-6">
                <Link href="/" className="text-textSecondary hover:text-accent mr-2">
                  <i className="fas fa-arrow-left"></i>
                </Link>
                <h1 className="text-2xl font-semibold text-textPrimary">{server.name}</h1>
                <span className={`ml-3 px-2 py-1 text-xs rounded-md ${server.status === 'online' ? 'bg-success bg-opacity-10 text-success' : 'bg-danger bg-opacity-10 text-danger'}`}>
                  {server.status === 'online' ? 'Online' : 'Offline'}
                </span>
              </div>
              
              <div className="flex flex-wrap gap-4 mb-6">
                <Button 
                  variant={server.status === 'online' ? 'destructive' : 'default'} 
                  onClick={() => handleServerAction(server.status === 'online' ? 'stop' : 'start')}
                  disabled={updateServerStatus.isPending}
                >
                  <i className={`fas ${server.status === 'online' ? 'fa-stop' : 'fa-play'} mr-2`}></i>
                  {server.status === 'online' ? 'Stop' : 'Start'}
                </Button>
                
                <Button 
                  variant="outline" 
                  onClick={() => handleServerAction('restart')}
                  disabled={server.status !== 'online' || updateServerStatus.isPending}
                >
                  <i className="fas fa-sync-alt mr-2"></i>
                  Restart
                </Button>
              </div>
              
              <Tabs defaultValue="overview" className="w-full">
                <TabsList className="mb-4">
                  <TabsTrigger value="overview">Overview</TabsTrigger>
                  <TabsTrigger value="console">Console</TabsTrigger>
                  <TabsTrigger value="players">Players</TabsTrigger>
                  <TabsTrigger value="files">Files</TabsTrigger>
                  <TabsTrigger value="settings">Settings</TabsTrigger>
                </TabsList>
                
                <TabsContent value="overview">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Server Information</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-textSecondary">Version:</span>
                            <span>{server.version}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-textSecondary">Type:</span>
                            <span>{server.type}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-textSecondary">Port:</span>
                            <span>{server.port}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-textSecondary">Uptime:</span>
                            <span>{server.uptime || 'Not running'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-textSecondary">Max Players:</span>
                            <span>{server.maxPlayers}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Performance</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-textSecondary">CPU Usage</span>
                              <span>{server.performance?.cpu || '0%'}</span>
                            </div>
                            <div className="h-3 rounded-full bg-foreground">
                              <div 
                                className="h-3 rounded-full bg-accent" 
                                style={{ width: `${server.performance?.cpu.replace('%', '') || 0}%` }}
                              ></div>
                            </div>
                          </div>
                          
                          <div>
                            <div className="flex justify-between mb-1">
                              <span className="text-textSecondary">Memory Usage</span>
                              <span>{server.performance?.memory || '0 MB'}</span>
                            </div>
                            <div className="h-3 rounded-full bg-foreground">
                              <div 
                                className="h-3 rounded-full bg-warning" 
                                style={{ width: `${server.performance?.memoryPercent || 0}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardHeader>
                        <CardTitle>Status</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="flex justify-between items-center mb-4">
                          <span>Auto-start on boot</span>
                          <Switch checked={server.autoStart} />
                        </div>
                        <div className="flex justify-between items-center mb-4">
                          <span>Auto-restart on crash</span>
                          <Switch checked={server.autoRestart} />
                        </div>
                        <div className="mt-6">
                          <h4 className="mb-2 font-medium">Quick Actions</h4>
                          <div className="grid grid-cols-2 gap-2">
                            <Button size="sm" variant="outline">Backup Now</Button>
                            <Button size="sm" variant="outline">Edit Config</Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
                
                <TabsContent value="console">
                  <Card>
                    <CardHeader>
                      <CardTitle>Server Console</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <Console serverId={id} socket={socket} />
                      <div className="flex mt-4 items-center">
                        <div className="flex-grow">
                          <input 
                            type="text" 
                            placeholder="Type command..." 
                            className="w-full rounded-md border border-border bg-background text-textPrimary px-4 py-2 focus:outline-none focus:ring-1 focus:ring-accent"
                            value={consoleCommand}
                            onChange={(e) => setConsoleCommand(e.target.value)}
                            onKeyPress={(e) => {
                              if (e.key === 'Enter') {
                                handleSendCommand();
                              }
                            }}
                          />
                        </div>
                        <button 
                          className="ml-2 px-4 py-2 rounded-md bg-accent text-white hover:bg-opacity-90"
                          onClick={handleSendCommand}
                        >
                          Send
                        </button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="players">
                  <Card>
                    <CardHeader>
                      <CardTitle>Online Players</CardTitle>
                    </CardHeader>
                    <CardContent>
                      {server.players && server.players.length > 0 ? (
                        <div className="space-y-4">
                          {server.players.map((player: any) => (
                            <div key={player.username} className="flex items-center justify-between border-b border-border pb-3 last:border-0 last:pb-0">
                              <div className="flex items-center">
                                <img className="w-10 h-10 rounded" src={`https://mc-heads.net/avatar/${player.username}`} alt="Player avatar" />
                                <div className="ml-3">
                                  <p className="text-sm font-medium text-textPrimary">{player.username}</p>
                                  <p className="text-xs text-textSecondary">{player.playtime} playtime</p>
                                </div>
                              </div>
                              <div className="flex items-center">
                                <div className="hidden md:block text-right text-xs text-textSecondary">
                                  <p>{player.gameMode}</p>
                                  <p>XYZ: {player.location}</p>
                                </div>
                                <div className="ml-3">
                                  <div className="dropdown relative">
                                    <button className="p-1 text-textSecondary hover:text-accent">
                                      <i className="fas fa-ellipsis-v"></i>
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center py-8 text-textSecondary">
                          No players online
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="files">
                  <Card>
                    <CardHeader>
                      <CardTitle>Server Files</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-8 text-textSecondary">
                        File browser functionality will be implemented soon
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
                
                <TabsContent value="settings">
                  <Card>
                    <CardHeader>
                      <CardTitle>Server Settings</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="text-center py-8 text-textSecondary">
                        Settings configuration UI will be implemented soon
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
