import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import Sidebar from '@/components/layout/Sidebar';
import Navbar from '@/components/layout/Navbar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Console } from '@/components/console/Console';
import { Button } from '@/components/ui/button';

type ServerConsoleProps = {
  id: string;
  socket: WebSocket | null;
};

export default function ServerConsole({ id, socket }: ServerConsoleProps) {
  const [showMobileSidebar, setShowMobileSidebar] = useState(false);
  const [consoleCommand, setConsoleCommand] = useState('');
  
  // Get server details
  const { data: server, isLoading } = useQuery<any>({
    queryKey: ['/api/servers', id],
  });
  
  // Send console command
  const handleSendCommand = () => {
    if (!consoleCommand.trim()) return;
    
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({
        type: 'command',
        serverId: id,
        command: consoleCommand
      }));
      setConsoleCommand('');
    }
  };
  
  return (
    <div className="flex h-screen overflow-hidden">
      {/* Mobile sidebar */}
      {showMobileSidebar && (
        <div className="fixed inset-0 z-40 md:hidden">
          <div className="fixed inset-0 bg-black bg-opacity-50" onClick={() => setShowMobileSidebar(false)} />
          <div className="fixed inset-y-0 left-0 z-40 w-64">
            <Sidebar />
          </div>
        </div>
      )}
      
      {/* Desktop sidebar */}
      <Sidebar />
      
      {/* Main Content */}
      <div className="flex flex-col flex-1 w-0 overflow-hidden">
        <Navbar onToggleSidebar={() => setShowMobileSidebar(!showMobileSidebar)} />
        
        {/* Page Content */}
        <main className="flex-1 overflow-y-auto bg-background focus:outline-none">
          <div className="py-6">
            <div className="px-4 mx-auto sm:px-6 md:px-8">
              <div className="flex items-center mb-6">
                <Link href={`/servers/${id}`} className="text-textSecondary hover:text-accent mr-2">
                  <i className="fas fa-arrow-left"></i>
                </Link>
                <h1 className="text-2xl font-semibold text-textPrimary">
                  {isLoading ? 'Loading...' : `Console - ${server?.name || 'Unknown Server'}`}
                </h1>
                {server && (
                  <span className={`ml-3 px-2 py-1 text-xs rounded-md ${server.status === 'online' ? 'bg-success bg-opacity-10 text-success' : 'bg-danger bg-opacity-10 text-danger'}`}>
                    {server.status === 'online' ? 'Online' : 'Offline'}
                  </span>
                )}
              </div>
              
              <Card className="mb-6">
                <CardHeader className="flex flex-row items-center justify-between">
                  <CardTitle>Server Console</CardTitle>
                  <div className="flex space-x-2">
                    <Button variant="outline" size="sm">
                      <i className="fas fa-expand-alt mr-2"></i>
                      Expand
                    </Button>
                    <Button variant="outline" size="sm">
                      <i className="fas fa-download mr-2"></i>
                      Download Logs
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {/* Larger console area for fullscreen view */}
                  <div className="console" style={{ height: '500px' }}>
                    <Console serverId={id} socket={socket} />
                  </div>
                  <div className="flex mt-4 items-center">
                    <div className="flex-grow">
                      <input 
                        type="text" 
                        placeholder="Type command..." 
                        className="w-full rounded-md border border-border bg-background text-textPrimary px-4 py-2 focus:outline-none focus:ring-1 focus:ring-accent"
                        value={consoleCommand}
                        onChange={(e) => setConsoleCommand(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            handleSendCommand();
                          }
                        }}
                      />
                    </div>
                    <button 
                      className="ml-2 px-4 py-2 rounded-md bg-accent text-white hover:bg-opacity-90"
                      onClick={handleSendCommand}
                    >
                      Send
                    </button>
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle>Common Commands</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                    <Button 
                      variant="outline" 
                      className="justify-start" 
                      onClick={() => {
                        setConsoleCommand('op <username>');
                      }}
                    >
                      <code className="mr-2">op &lt;username&gt;</code>
                      <span className="text-xs text-textSecondary">Give operator status</span>
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      className="justify-start" 
                      onClick={() => {
                        setConsoleCommand('gamemode creative <username>');
                      }}
                    >
                      <code className="mr-2">gamemode creative</code>
                      <span className="text-xs text-textSecondary">Change game mode</span>
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      className="justify-start" 
                      onClick={() => {
                        setConsoleCommand('time set day');
                      }}
                    >
                      <code className="mr-2">time set day</code>
                      <span className="text-xs text-textSecondary">Set time to day</span>
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      className="justify-start" 
                      onClick={() => {
                        setConsoleCommand('weather clear');
                      }}
                    >
                      <code className="mr-2">weather clear</code>
                      <span className="text-xs text-textSecondary">Clear weather</span>
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      className="justify-start" 
                      onClick={() => {
                        setConsoleCommand('say Hello everyone!');
                      }}
                    >
                      <code className="mr-2">say &lt;message&gt;</code>
                      <span className="text-xs text-textSecondary">Broadcast message</span>
                    </Button>
                    
                    <Button 
                      variant="outline" 
                      className="justify-start" 
                      onClick={() => {
                        setConsoleCommand('list');
                      }}
                    >
                      <code className="mr-2">list</code>
                      <span className="text-xs text-textSecondary">List online players</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
