import { Switch, Route } from "wouter";
import Dashboard from "./pages/Dashboard";
import ServerDetail from "./pages/servers/ServerDetail";
import ServerConsole from "./pages/servers/ServerConsole";
import AuthPage from "./pages/auth-page";
import NotFound from "./pages/not-found";
import { useState, useEffect } from "react";
import { AuthProvider } from "./hooks/use-auth";
import { ProtectedRoute } from "./lib/protected-route";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";

function Router() {
  const [isSocketConnected, setIsSocketConnected] = useState(false);
  const [socket, setSocket] = useState<WebSocket | null>(null);

  useEffect(() => {
    // Create WebSocket connection
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsSocket = new WebSocket(`${protocol}//${window.location.host}/ws`);
    
    wsSocket.onopen = () => {
      console.log("WebSocket connected");
      setIsSocketConnected(true);
    };
    
    wsSocket.onclose = () => {
      console.log("WebSocket disconnected");
      setIsSocketConnected(false);
      
      // Reconnect after a delay
      setTimeout(() => {
        console.log("Attempting to reconnect WebSocket...");
        const newSocket = new WebSocket(`${protocol}//${window.location.host}/ws`);
        setSocket(newSocket);
      }, 3000);
    };
    
    wsSocket.onerror = (error) => {
      console.error("WebSocket error:", error);
    };
    
    setSocket(wsSocket);
    
    // Clean up the WebSocket connection on unmount
    return () => {
      if (wsSocket && wsSocket.readyState === WebSocket.OPEN) {
        wsSocket.close();
      }
    };
  }, []);

  return (
    <Switch>
      <ProtectedRoute 
        path="/" 
        component={() => <Dashboard socket={socket} />} 
      />
      <ProtectedRoute 
        path="/servers/:id" 
        component={(params) => <ServerDetail id={params.id} socket={socket} />} 
      />
      <ProtectedRoute 
        path="/servers/:id/console" 
        component={(params) => <ServerConsole id={params.id} socket={socket} />} 
      />
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
