import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

type SidebarProps = {
  username?: string;
  role?: string;
};

export default function Sidebar({ username = "Admin User", role = "Administrator" }: SidebarProps) {
  const [location] = useLocation();

  const navItems = [
    { name: "Dashboard", path: "/", icon: "fas fa-tachometer-alt" },
    { name: "Servers", path: "/servers", icon: "fas fa-server" },
    { name: "Users", path: "/users", icon: "fas fa-user-friends" },
    { name: "Scheduler", path: "/scheduler", icon: "fas fa-clock" },
    { name: "Backups", path: "/backups", icon: "fas fa-database" },
    { name: "Files", path: "/files", icon: "fas fa-file-alt" },
    { name: "Integrations", path: "/integrations", icon: "fas fa-plug" },
    { name: "Settings", path: "/settings", icon: "fas fa-cog" }
  ];

  return (
    <div className="hidden md:flex md:flex-shrink-0">
      <div className="flex flex-col w-64 border-r border-border bg-foreground">
        <div className="flex items-center justify-center h-16 px-4 border-b border-border bg-background">
          <h1 className="text-xl font-semibold text-textPrimary">MC Controller</h1>
        </div>
        <div className="flex flex-col flex-grow px-4 py-4 overflow-y-auto">
          <nav className="flex-1 space-y-1">
            {navItems.map((item) => {
              const isActive = location === item.path || 
                               (item.path !== "/" && location.startsWith(item.path));
              
              return (
                <Link 
                  key={item.path} 
                  href={item.path}
                  className={cn(
                    "flex items-center px-2 py-2 text-sm font-medium rounded-md", 
                    isActive 
                      ? "bg-accent bg-opacity-10 text-accent" 
                      : "text-textPrimary hover:bg-background hover:text-accent",
                    item.name !== "Dashboard" && "mt-1"
                  )}
                >
                  <i className={cn(item.icon, "mr-3 h-4 w-4")}></i>
                  {item.name}
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="p-4 border-t border-border">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <img className="w-8 h-8 rounded-full" src="https://www.gravatar.com/avatar/00000000000000000000000000000000?d=mp&f=y" alt="User avatar" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-textPrimary">{username}</p>
              <p className="text-xs text-textSecondary">{role}</p>
            </div>
            <button className="p-1 ml-auto text-textSecondary rounded-full hover:text-accent hover:bg-background">
              <i className="fas fa-sign-out-alt"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
