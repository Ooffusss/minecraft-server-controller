import { useState } from 'react';
import { Input } from '@/components/ui/input';

type NavbarProps = {
  onToggleSidebar: () => void;
};

export default function Navbar({ onToggleSidebar }: NavbarProps) {
  const [searchQuery, setSearchQuery] = useState('');
  
  return (
    <div className="relative z-10 flex flex-shrink-0 h-16 bg-foreground border-b border-border">
      <button 
        type="button" 
        className="px-4 text-textPrimary md:hidden"
        onClick={onToggleSidebar}
      >
        <i className="fas fa-bars"></i>
      </button>
      
      <div className="flex items-center justify-between flex-1 px-4">
        <div className="flex items-center flex-1">
          <div className="max-w-xs w-full lg:max-w-md">
            <label htmlFor="search" className="sr-only">Search</label>
            <div className="relative text-textSecondary focus-within:text-textPrimary">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <i className="fas fa-search"></i>
              </div>
              <Input
                id="search"
                className="block w-full py-2 pl-10 pr-3 leading-5 placeholder-textSecondary bg-background border border-border rounded-md focus:outline-none focus:ring-1 focus:ring-accent text-textPrimary"
                placeholder="Search servers, users..."
                type="search"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>
        <div className="flex items-center ml-4 md:ml-6">
          <button className="p-1 text-textSecondary rounded-full hover:bg-background hover:text-accent">
            <i className="fas fa-bell"></i>
          </button>
          <button className="p-1 ml-3 text-textSecondary rounded-full hover:bg-background hover:text-accent">
            <i className="fas fa-question-circle"></i>
          </button>
        </div>
      </div>
    </div>
  );
}
