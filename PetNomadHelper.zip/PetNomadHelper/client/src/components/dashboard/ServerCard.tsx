import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Link, useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { cn } from '@/lib/utils';

type ServerCardProps = {
  server: any;
  onConsoleClick: () => void;
};

export default function ServerCard({ server, onConsoleClick }: ServerCardProps) {
  const [location, navigate] = useLocation();
  const { toast } = useToast();
  const [isTogglingServer, setIsTogglingServer] = useState(false);
  
  // Server toggle mutation
  const toggleServer = useMutation({
    mutationFn: async () => {
      const action = server.status === 'online' ? 'stop' : 'start';
      return apiRequest('POST', `/api/servers/${server.id}/${action}`, {});
    },
    onMutate: () => {
      setIsTogglingServer(true);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/servers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/servers', server.id] });
      setIsTogglingServer(false);
      toast({
        title: `Server ${server.status === 'online' ? 'Stopped' : 'Started'}`,
        description: `${server.name} has been ${server.status === 'online' ? 'stopped' : 'started'} successfully.`
      });
    },
    onError: (error) => {
      setIsTogglingServer(false);
      toast({
        title: "Error",
        description: `Failed to ${server.status === 'online' ? 'stop' : 'start'} the server: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Server restart mutation
  const restartServer = useMutation({
    mutationFn: async () => {
      return apiRequest('POST', `/api/servers/${server.id}/restart`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/servers'] });
      queryClient.invalidateQueries({ queryKey: ['/api/servers', server.id] });
      toast({
        title: "Server Restarting",
        description: `${server.name} is restarting.`
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to restart the server: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Handle toggling the server on/off
  const handleServerToggle = (checked: boolean) => {
    if (isTogglingServer) return;
    toggleServer.mutate();
  };
  
  return (
    <Card className="bg-foreground overflow-hidden rounded-lg shadow">
      <CardContent className="px-4 py-5">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className={`w-2 h-2 rounded-full ${server.status === 'online' ? 'bg-success' : 'bg-danger'} mr-2`}></div>
            <h3 className="text-lg font-medium text-textPrimary">{server.name}</h3>
          </div>
          <div className="ml-2 flex-shrink-0 flex">
            <p className={cn(
              "px-2 inline-flex text-xs leading-5 font-semibold rounded-full",
              server.status === 'online' 
                ? "bg-success bg-opacity-10 text-success" 
                : "bg-danger bg-opacity-10 text-danger"
            )}>
              {server.status === 'online' ? 'Online' : 'Offline'}
            </p>
          </div>
        </div>
        
        <div className="mt-4 flex items-center justify-between text-sm text-textSecondary">
          <span>{server.type} • {server.version}</span>
          <span>{server.players ? `${server.players.length}/${server.maxPlayers} players` : '0/0 players'}</span>
        </div>
        
        <div className="mt-6 grid grid-cols-3 gap-3 text-center">
          <div className="px-2 py-3 rounded-md bg-background">
            <p className="text-sm font-medium text-textSecondary">Uptime</p>
            <p className="mt-1 text-accent font-medium">{server.uptime || '-'}</p>
          </div>
          <div className="px-2 py-3 rounded-md bg-background">
            <p className="text-sm font-medium text-textSecondary">CPU</p>
            <p className="mt-1 text-accent font-medium">{server.performance?.cpu || '0%'}</p>
          </div>
          <div className="px-2 py-3 rounded-md bg-background">
            <p className="text-sm font-medium text-textSecondary">RAM</p>
            <p className="mt-1 text-accent font-medium">{server.performance?.memory || '0 GB'}</p>
          </div>
        </div>
        
        <div className="mt-5 flex justify-between">
          <div className="relative inline-block align-middle select-none">
            <Switch 
              checked={server.status === 'online'} 
              onCheckedChange={handleServerToggle}
              disabled={isTogglingServer || toggleServer.isPending}
            />
          </div>
          <div className="flex space-x-2">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <button 
                    className="p-2 rounded-md bg-background text-textSecondary hover:text-accent"
                    onClick={() => restartServer.mutate()}
                    disabled={server.status !== 'online' || restartServer.isPending}
                  >
                    <i className="fas fa-sync-alt"></i>
                  </button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Restart Server</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <button 
                    className="p-2 rounded-md bg-background text-textSecondary hover:text-accent"
                    onClick={onConsoleClick}
                  >
                    <i className="fas fa-terminal"></i>
                  </button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Console</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
            
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Link href={`/servers/${server.id}`} className="p-2 rounded-md bg-background text-textSecondary hover:text-accent">
                    <i className="fas fa-cog"></i>
                  </Link>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Server Settings</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
