import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

type Player = {
  username: string;
  playtime: string;
  gameMode: string;
  location: string;
};

type PlayerListProps = {
  players: Player[];
};

export default function PlayerList({ players }: PlayerListProps) {
  return (
    <div className="bg-foreground rounded-lg shadow">
      <div className="px-4 py-5 border-b border-border sm:px-6">
        <h3 className="text-lg font-medium text-textPrimary">Online Players</h3>
      </div>
      <div className="px-4 py-5 sm:p-6">
        {players && players.length > 0 ? (
          <div className="space-y-4">
            {players.map((player) => (
              <div key={player.username} className="flex items-center justify-between border-b border-border pb-3 last:border-0 last:pb-0">
                <div className="flex items-center">
                  <img className="w-10 h-10 rounded" src={`https://mc-heads.net/avatar/${player.username}`} alt="Player avatar" />
                  <div className="ml-3">
                    <p className="text-sm font-medium text-textPrimary">{player.username}</p>
                    <p className="text-xs text-textSecondary">{player.playtime} playtime</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="hidden md:block text-right text-xs text-textSecondary">
                    <p>{player.gameMode}</p>
                    <p>XYZ: {player.location}</p>
                  </div>
                  <div className="ml-3">
                    <div className="dropdown relative">
                      <button className="p-1 text-textSecondary hover:text-accent">
                        <i className="fas fa-ellipsis-v"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
            
            <div className="mt-4">
              <Button variant="outline" className="w-full py-2 text-accent text-sm hover:bg-accent hover:bg-opacity-10">
                View All Players
              </Button>
            </div>
          </div>
        ) : (
          <div className="text-center py-8 text-textSecondary">
            No players online
          </div>
        )}
      </div>
    </div>
  );
}
