import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Button } from "@/components/ui/button";

type Task = {
  id: string;
  name: string;
  server: string;
  schedule: string;
  lastRun: string;
  status: 'success' | 'partial' | 'failed' | 'pending';
};

type TaskTableProps = {
  tasks: Task[];
};

export default function TaskTable({ tasks }: TaskTableProps) {
  const { toast } = useToast();
  
  // Delete task mutation
  const deleteTask = useMutation({
    mutationFn: async (taskId: string) => {
      return apiRequest('DELETE', `/api/tasks/${taskId}`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Task Deleted",
        description: "The scheduled task has been removed."
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete task: ${error.message}`,
        variant: "destructive"
      });
    }
  });
  
  // Get status badge class
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'success':
        return 'bg-success bg-opacity-10 text-success';
      case 'partial':
        return 'bg-warning bg-opacity-10 text-warning';
      case 'failed':
        return 'bg-danger bg-opacity-10 text-danger';
      case 'pending':
        return 'bg-accent bg-opacity-10 text-accent';
      default:
        return 'bg-muted bg-opacity-10 text-muted-foreground';
    }
  };
  
  // Handle delete task
  const handleDeleteTask = (taskId: string) => {
    if (confirm('Are you sure you want to delete this task?')) {
      deleteTask.mutate(taskId);
    }
  };
  
  return (
    <div className="mt-8">
      <h2 className="flex items-center text-lg font-medium text-textPrimary">
        Scheduled Tasks
        <button className="ml-3 p-1 text-sm text-accent hover:bg-accent hover:bg-opacity-10 rounded-md">
          <i className="fas fa-plus-circle"></i> Add Task
        </button>
      </h2>
      
      <div className="mt-4 bg-foreground shadow overflow-hidden rounded-lg">
        <div className="bg-foreground px-4 py-5 border-b border-border sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-textPrimary">
            Active Tasks
          </h3>
        </div>
        <div className="bg-foreground overflow-x-auto">
          {tasks && tasks.length > 0 ? (
            <table className="min-w-full divide-y divide-border">
              <thead>
                <tr>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-textSecondary uppercase tracking-wider">
                    Task
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-textSecondary uppercase tracking-wider">
                    Server
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-textSecondary uppercase tracking-wider">
                    Schedule
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-textSecondary uppercase tracking-wider">
                    Last Run
                  </th>
                  <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-textSecondary uppercase tracking-wider">
                    Status
                  </th>
                  <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-textSecondary uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {tasks.map((task) => (
                  <tr key={task.id}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-textPrimary">
                      {task.name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-textPrimary">
                      {task.server}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-textSecondary">
                      {task.schedule}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-textSecondary">
                      {task.lastRun}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(task.status || 'pending')}`}>
                        {task.status ? task.status.charAt(0).toUpperCase() + task.status.slice(1) : 'Pending'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                      <button className="text-textSecondary hover:text-accent mx-1">
                        <i className="fas fa-edit"></i>
                      </button>
                      <button 
                        className="text-textSecondary hover:text-danger mx-1" 
                        onClick={() => handleDeleteTask(task.id)}
                        disabled={deleteTask.isPending}
                      >
                        <i className="fas fa-trash"></i>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="text-center py-8 text-textSecondary">
              No scheduled tasks. Click "Add Task" to create one.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
