import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

type MetricCardProps = {
  title: string;
  value: string;
  icon: string;
  iconColor: 'accent' | 'success' | 'warning' | 'danger';
  progress?: number;
  progressColor?: 'accent' | 'success' | 'warning' | 'danger';
  subtext?: string;
};

export default function MetricCard({
  title,
  value,
  icon,
  iconColor,
  progress,
  progressColor = 'accent',
  subtext
}: MetricCardProps) {
  return (
    <div className="overflow-hidden bg-foreground rounded-lg shadow">
      <div className="p-5">
        <div className="flex items-center">
          <div className={`flex-shrink-0 p-3 bg-${iconColor} bg-opacity-10 rounded-md`}>
            <i className={`${icon} text-${iconColor}`}></i>
          </div>
          <div className="flex-1 ml-5 w-0">
            <dl>
              <dt className="text-sm font-medium truncate text-textSecondary">{title}</dt>
              <dd className="flex items-baseline">
                <div className="text-2xl font-semibold text-textPrimary">{value}</div>
              </dd>
            </dl>
          </div>
        </div>
      </div>
      
      {progress !== undefined ? (
        <div className="bg-background px-5 py-3">
          <div className="h-3 rounded-full bg-foreground">
            <div 
              className={`h-3 rounded-full bg-${progressColor}`} 
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>
      ) : subtext ? (
        <div className="bg-background px-5 py-3">
          <div className="text-sm text-textSecondary">
            {subtext}
          </div>
        </div>
      ) : null}
    </div>
  );
}
