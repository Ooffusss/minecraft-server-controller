import { useState, useEffect, useRef } from 'react';

type ConsoleProps = {
  serverId: string | null;
  socket: WebSocket | null;
};

type ConsoleMessage = {
  timestamp: string;
  content: string;
  type: 'info' | 'error' | 'warning' | 'success' | 'chat' | 'player';
};

export function Console({ serverId, socket }: ConsoleProps) {
  const [messages, setMessages] = useState<ConsoleMessage[]>([]);
  const consoleRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    if (!socket || !serverId) return;
    
    // Function to handle WebSocket messages
    const handleSocketMessage = (event: MessageEvent) => {
      try {
        const data = JSON.parse(event.data);
        
        // Only process console messages for the selected server
        if (data.type === 'console' && data.serverId === serverId) {
          setMessages((prev) => [...prev, data.message]);
          
          // Auto-scroll to bottom
          if (consoleRef.current) {
            consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
          }
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    // Listen for WebSocket messages
    socket.addEventListener('message', handleSocketMessage);
    
    // Request console history for this server
    if (socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify({ 
        type: 'getConsoleHistory', 
        serverId 
      }));
    } else {
      // Wait for socket to open then send request
      const checkSocketAndSend = () => {
        if (socket.readyState === WebSocket.OPEN) {
          socket.send(JSON.stringify({ 
            type: 'getConsoleHistory', 
            serverId 
          }));
        } else if (socket.readyState !== WebSocket.CLOSING && socket.readyState !== WebSocket.CLOSED) {
          setTimeout(checkSocketAndSend, 500);
        }
      };
      setTimeout(checkSocketAndSend, 500);
    }
    
    // Clean up event listener on unmount
    return () => {
      socket.removeEventListener('message', handleSocketMessage);
    };
  }, [socket, serverId]);
  
  const getMessageClass = (type: string) => {
    switch (type) {
      case 'error':
        return 'text-danger';
      case 'warning':
        return 'text-warning';
      case 'success':
        return 'text-success';
      case 'player':
        return 'text-blue-400';
      case 'chat':
        return 'text-textSecondary';
      default:
        return 'text-textSecondary';
    }
  };
  
  if (!serverId) {
    return (
      <div className="console rounded-md font-mono text-sm">
        <div className="console-line text-textSecondary">No server selected</div>
      </div>
    );
  }
  
  return (
    <div ref={consoleRef} className="console rounded-md font-mono text-sm">
      {messages.length === 0 ? (
        <div className="console-line text-textSecondary">No console output available</div>
      ) : (
        messages.map((msg, index) => (
          <div key={index} className={`console-line ${getMessageClass(msg.type)}`}>
            {msg.content}
          </div>
        ))
      )}
    </div>
  );
}
